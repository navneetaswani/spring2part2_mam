
Hibernate Tutorials

https://docs.jboss.org/hibernate/orm/5.0/manual/en-US/html/pr01.html



Caching 

https://www.ehcache.org/documentation/2.7/integrations/hibernate.html

