package demo;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Id;

public class EmpPK implements Serializable {
	
	private String firstname;
	
	private String lastname;

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	@Override
	public String toString() {
		return "EmpPK [firstname=" + firstname + ", lastname=" + lastname + "]";
	}
	
}
