package demo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Transient;

@Entity
@Table(name = "mytable")
public class Emp  {
	
	@EmbeddedId
	private EmpPK pk;
	
	@Embedded
	private Address addr;
	
	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}
	
	public EmpPK getPk() {
		return pk;
	}
	public void setPk(EmpPK pk) {
		this.pk = pk;
	}
	@Override
	public String toString() {
		return "Emp [pk=" + pk + ", addr=" + addr + "]";
	}

}
