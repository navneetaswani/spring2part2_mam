import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import demo.Emp;
import demo.EmpPK;
import util.HibernateUtil;

public class EmpDAO {
	private static SessionFactory sf = HibernateUtil.getSessionfactory();

	public void get() {
		Session session = null;

		try {
			session = sf.openSession();
			EmpPK pk = new EmpPK();
			pk.setFirstname("vai");
			pk.setLastname("tap");
			Emp e = session.get(Emp.class,pk);
			System.out.println(e);
		
		} catch (Exception e) {

			System.out.println("Exception " + e);
		} finally {
			session.close();
		}
	}



	public void insert() {
		Session session = null;
		Transaction tx = null;
		try {
			session = sf.openSession();
			tx = session.beginTransaction();
			Emp e = new Emp();
			EmpPK pk = new EmpPK();
			pk.setFirstname("vai");
			pk.setLastname("tap");
			e.setPk(pk);
			session.save(e);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			System.out.println("Exception " + e);
		} finally {
			session.close();
		}
	}

	public static void main(String[] args) {
		EmpDAO dao = new EmpDAO();
		dao.insert();
		dao.get();
	}
}
