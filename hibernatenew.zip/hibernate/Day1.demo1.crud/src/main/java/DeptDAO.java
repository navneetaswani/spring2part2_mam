import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import demo.Dept;
import util.HibernateUtil;

public class DeptDAO {
	private static SessionFactory sf = HibernateUtil.getSessionfactory();

	public void list() {
		Session session = null;

		try {
			session = sf.openSession();
			// SQL => HQL => JPQL
		 Query<Dept> query = session.createQuery("select d from Dept d where d.loc = 'Hyd'");
			//Query<Dept> query = session.createQuery("select d from Dept d where  d.dname = 'HR' ");
			List<Dept> list = query.list();
			for (Dept dept : list) {
				System.out.println(dept);
			}
		} catch (Exception e) {

			System.out.println("Exception " + e);
		} finally {
			session.close();
		}
	}

	public void update(int deptno, String newdname, String newloc) {
		Session session = null;
		Transaction tx = null;
		try {
			session = sf.openSession();
			tx = session.beginTransaction();
			Dept d = session.get(Dept.class, deptno);
			if (d != null) {
				d.setDname(newdname);
				d.setLoc(newloc);
			}

			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			System.out.println("Exception " + e);
		} finally {
			session.close();
		}

	}

	public void delete(int deptno) {
		Session session = null;
		Transaction tx = null;
		try {
			session = sf.openSession();
			tx = session.beginTransaction();
			/*
			 * Dept d = new Dept(); d.setDeptno(deptno);
			 */
			// get - eager loader
			/*
			 * Dept d = session.get(Dept.class,deptno); if (d != null)
			 * session.delete(d); else
			 * System.out.println("Record Not Found ...");
			 */
			// load - lazy loader
			Dept d = session.load(Dept.class, deptno);
			System.out.println(d.getDname());
			session.delete(d);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			System.out.println("Exception " + e);
		} finally {
			session.close();
		}
	}

	public void insert(Dept d) {
		Session session = null;
		Transaction tx = null;
		try {
			session = sf.openSession();
			tx = session.beginTransaction();
			// d - transient
			System.out.println(session.save(d));
			// d - persistent/attached
			tx.commit();
			d.setLoc("Pune");
			System.out.println(d);
		} catch (Exception e) {
			tx.rollback();
			System.out.println("Exception " + e);
		} finally {
			session.close();
		}
	}

	public static void main(String[] args) {
		DeptDAO dao = new DeptDAO();
		for (int i = 10; i < 100; i += 10) {
			Dept d = new Dept();
		//	d.setDeptno(i);
			d.setDname("HR" + i);
			if ((i % 20) == 0)
				d.setLoc("Hyd");
			else
				d.setLoc("Blr");

			dao.insert(d);
		}
		dao.delete(20);
		dao.update(10, "HR", "Indore");
		dao.list();
		sf.close();
	}
}
