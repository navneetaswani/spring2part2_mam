package demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name="depttable")
public class Dept {
/*	@Id
	@Column(name="deptnoCol")*/
	@Id
/*	@GeneratedValue(strategy=GenerationType.AUTO,generator="mygen")
	@SequenceGenerator(name="mygen",sequenceName="mysequence",
				initialValue=100,allocationSize=5)
*/
	
	@GeneratedValue(strategy=GenerationType.TABLE,generator="mytabgen")
	@TableGenerator(name="mytabgen",table="pks",
	       pkColumnName="pkcolname",valueColumnName="currvalue",initialValue=10)
	private int deptno;
	@Column(name="dnameCol",length=20)
	private String dname;
	@Column(name="loc")
	private String loc;
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	@Override
	public String toString() {
		return "Dept [deptno=" + deptno + ", dname=" + dname + ", loc=" + loc + "]";
	}
	
	
}
